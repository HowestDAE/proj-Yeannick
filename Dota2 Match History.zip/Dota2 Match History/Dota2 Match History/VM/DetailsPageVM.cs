﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GalaSoft.MvvmLight;
using Dota2_Match_History.Models;
using Dota2_Match_History.Repositories;

namespace Dota2_Match_History.VM
{
    class DetailsPageVM : ViewModelBase
    {
        private long _matchId;

        public long MatchId
        {
            get { return _matchId; }
            set { _matchId = value; }
        }
        public Match CurrentMatch { get; set; }

        public async Task LoadMatch()
        {
            IRepository currentRepository = RepositoryManager.GetInstance().CurrentRepository;
            CurrentMatch = await currentRepository.GetMatch(MatchId);
            RaisePropertyChanged("CurrentMatch");
        }
    }
}
